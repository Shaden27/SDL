package Backend;

import java.io.*;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.List;

public class Server {
    public static void main(String[] args) throws IOException, ClassNotFoundException, EOFException {
        System.out.println("Hello");
        Class.forName("com.mysql.cj.jdbc.Driver");
        Source sour = new Source();
        if (sour.open()) {
            sour.createOfficeTable();
            sour.createCustomerTable();
            sour.createTransactionTable();
            System.out.println("Database created successfully");
        } else {
            System.out.println("Database couldn't be created");
        }
        ServerSocket serverSocket = new ServerSocket(8020);
        Socket socket = serverSocket.accept();
        System.out.println("Client Connected");
        DataOutputStream dout;
        ObjectInputStream oin;
        ObjectOutputStream oout;
        String choice;
        DataInputStream din = new DataInputStream(socket.getInputStream());
        while(true) {
            choice = din.readUTF();
            System.out.println("choice: " + choice);
            switch (choice) {
                case "submit_officeName": {
                    dout = new DataOutputStream(socket.getOutputStream());
                    String officeName = din.readUTF();
                    System.out.println("officeName from Server: " + officeName);
                    if (sour.addOffice(officeName) >= 0) {
                        dout.writeUTF(officeName + " Added Successfully");
                    } else {
                        dout.writeUTF(officeName + " already exists");
                    }
                    break;
                }

                case "submit_customer": {
                    System.out.println("popuauau");
                    dout = new DataOutputStream(socket.getOutputStream());
                    int office_id = din.readInt();
                    oin = new ObjectInputStream(socket.getInputStream());
                    Customer customer = (Customer) oin.readObject();
                    System.out.println(customer.getAddress());
                    if (sour.addCustomer(customer.getName(), customer.getPhone(), customer.getAddress(), customer.getAge(), office_id) >= 0) {
                        dout.writeUTF("The customer " + customer.getName() + " has been added");
                    } else {
                        dout.writeUTF("Enter valid Phone Number \n Cannot add customer");
                    }
                    break;
                }

                case "submit_addAmount": {
                    dout = new DataOutputStream(socket.getOutputStream());
                    int office_id = din.readInt();
                    String phone = din.readUTF();
                    double addAmount = din.readDouble();
                    if (sour.addAmount(phone, addAmount, office_id) >= 0) {
                        dout.writeUTF("The customer with phone number " + phone + " has done an additional transaction of " + addAmount);
                    } else {
                        dout.writeUTF("Customer not Found..\nCannot make transactions");
                    }
                    break;
                }

                case "submit_withdrawAmount": {
                    dout = new DataOutputStream(socket.getOutputStream());
                    int office_id = din.readInt();
                    String phone = din.readUTF();
                    double withdrawAmount = din.readDouble();
                    if (sour.WithdrawAmount(phone, withdrawAmount, office_id) >= 0) {
                        dout.writeUTF("The customer with phone number " + phone + " withdrew an amount of " + withdrawAmount);
                    } else {
                        dout.writeUTF("Customer not Found..\nCannot make transactions");
                    }
                    break;
                }

                case "submit_searchCustomer": {
                    dout = new DataOutputStream(socket.getOutputStream());
                    String CustomerName = din.readUTF();
                    String phone = din.readUTF();
                    if (sour.queryCustomer(phone) != null) {
                        dout.writeUTF("Customer with name " + CustomerName + " and phone number " + phone + " Found");
                    } else {
                        dout.writeUTF("Record not Found");
                    }
                    break;
                }

                case "submit_deleteCustomer": {
                    dout = new DataOutputStream(socket.getOutputStream());
                    String phone = din.readUTF();
                    if (sour.deleteCusomer(phone) >= 0) {
                        dout.writeUTF("Customer with phone number " + phone + " Deleted Successfully");
                    } else {
                        dout.writeUTF("Record not Found");
                    }
                    break;
                }

                case "submit_viewTransactions": {
                    dout = new DataOutputStream(socket.getOutputStream());
                    String phone = din.readUTF();
                    List<Transaction> list = sour.viewTransactions(phone);
                    dout.writeInt(list.size());
                    for (Transaction transaction : list) {
                        dout.writeUTF(transaction.toString());
                    }
                    break;
                }
            }
        }
    }
}
