package Backend;

import java.util.ArrayList;

public class Office {

    private int office_id;
    private String officeName;
    
    public Office(String OfficeName) {
        this.officeName=OfficeName;
    }

    public int getOffice_id() {
        return office_id;
    }
    
    public void setOffice_id(int office_id) {
        this.office_id = office_id;
    }

    public String getOfficeName() {
        return officeName;
    }

    public void setOfficeName(String officeName) {
        this.officeName = officeName;
    }
}

