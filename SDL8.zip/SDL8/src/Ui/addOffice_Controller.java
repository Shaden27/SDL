package Ui;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

public class addOffice_Controller {
    @FXML
    private TextField office_name;

    @FXML
    private Button submit_officeName;

    @FXML
    private Button exit;

    @FXML
    private Label result;
    
    @FXML
    public void initialize() {
        submit_officeName.setDisable(true);
    }

    @FXML
    public void onButtonClicked(ActionEvent event) {
        try(Socket socket=new Socket("localhost", 8020);
            DataOutputStream dout=new DataOutputStream(socket.getOutputStream());
            DataInputStream din=new DataInputStream(socket.getInputStream())){
            String officeName=office_name.getText();
            System.out.println("officeName: "+officeName);

            dout.writeUTF(submit_officeName.getId());
            dout.writeUTF(officeName);
            result.setText(din.readUTF());
            socket.close();
        }
        catch(IOException e) {
            System.out.println("IOException: "+e.getMessage());
        }
    }

    @FXML
    public void onExit(ActionEvent event) throws Exception {
        Node source=(Node) event.getSource();
        Stage prevStage=(Stage)source.getScene().getWindow();
        prevStage.close();
        Parent root=FXMLLoader.load(getClass().getResource("MainPage.fxml"));
        Stage stage = new Stage();
        Scene scene = new Scene(root, 1100, 1100);
        stage.setScene(scene);
        stage.setTitle("Main Page");
        stage.show();
    }
    
    @FXML
    public void handleKeyReleased() {
        String officeName=office_name.getText();
        boolean disabled= officeName.isEmpty() || officeName.trim().isEmpty();
        submit_officeName.setDisable(disabled);
    }
}
